$('.ckeditor').ckeditor({
  // optional config
});