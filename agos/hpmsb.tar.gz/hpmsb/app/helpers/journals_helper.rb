module JournalsHelper
end
