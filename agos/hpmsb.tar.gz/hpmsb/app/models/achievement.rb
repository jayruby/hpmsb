class Achievement < ActiveRecord::Base
end
