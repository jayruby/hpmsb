class DivisionCategory < ActiveRecord::Base
  belongs_to :Division
end
