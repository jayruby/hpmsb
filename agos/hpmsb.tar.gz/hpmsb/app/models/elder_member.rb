class ElderMember < ActiveRecord::Base

end
