class Journal < ActiveRecord::Base
end
