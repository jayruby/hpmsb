class PostCategory < ActiveRecord::Base
  belongs_to :Post
end
