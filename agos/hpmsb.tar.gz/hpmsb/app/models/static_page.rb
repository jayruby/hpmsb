class StaticPage < ActiveRecord::Base
end
