require 'test_helper'

class AgendasHelperTest < ActionView::TestCase
end
