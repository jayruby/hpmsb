require 'test_helper'

class AlumnisHelperTest < ActionView::TestCase
end
