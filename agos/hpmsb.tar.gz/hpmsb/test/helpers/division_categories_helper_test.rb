require 'test_helper'

class DivisionCategoriesHelperTest < ActionView::TestCase
end
