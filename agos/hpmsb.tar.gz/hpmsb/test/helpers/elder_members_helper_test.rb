require 'test_helper'

class ElderMembersHelperTest < ActionView::TestCase
end
