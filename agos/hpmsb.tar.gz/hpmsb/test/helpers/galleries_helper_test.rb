require 'test_helper'

class GalleriesHelperTest < ActionView::TestCase
end
