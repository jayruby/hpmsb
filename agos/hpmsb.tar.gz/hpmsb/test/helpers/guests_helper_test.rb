require 'test_helper'

class GuestsHelperTest < ActionView::TestCase
end
