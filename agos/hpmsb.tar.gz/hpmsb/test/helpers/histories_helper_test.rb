require 'test_helper'

class HistoriesHelperTest < ActionView::TestCase
end
