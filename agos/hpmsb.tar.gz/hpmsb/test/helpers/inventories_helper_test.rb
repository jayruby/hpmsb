require 'test_helper'

class InventoriesHelperTest < ActionView::TestCase
end
