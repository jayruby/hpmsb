require 'test_helper'

class JournalsHelperTest < ActionView::TestCase
end
