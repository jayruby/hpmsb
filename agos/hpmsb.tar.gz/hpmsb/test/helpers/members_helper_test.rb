require 'test_helper'

class MembersHelperTest < ActionView::TestCase
end
