require 'test_helper'

class PostCategoriesHelperTest < ActionView::TestCase
end
