require 'test_helper'

class AgendaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
