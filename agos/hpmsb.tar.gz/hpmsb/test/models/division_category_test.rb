require 'test_helper'

class DivisionCategoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
