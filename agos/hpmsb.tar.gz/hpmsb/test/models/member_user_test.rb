require 'test_helper'

class MemberUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
